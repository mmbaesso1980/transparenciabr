"""
Ocean Ways — Route: /api/v1/payments  (Stripe-only)
=======================================================
Stripe Web Checkout é o único gateway live agora (decisão Comandante 30/mai 2026).
Mercado Pago foi descartado. Apple Pay e Google Pay são roadmap do app mobile.

Fluxo Stripe:
  1. Frontend POST /payments/stripe/checkout com product=PLAN_PRO|TOPUP_100
  2. Backend cria Stripe Checkout Session e retorna URL
  3. Frontend redireciona pro Stripe
  4. Stripe chama POST /payments/stripe/webhook após pagamento
  5. Webhook valida assinatura, credita créditos, atualiza Firestore

TODO (mobile):
  - apple-pay: implementar no app iOS futuro via Stripe PaymentRequest API
  - google-pay: implementar no app Android futuro via Stripe PaymentRequest API
"""

import os
import logging
from fastapi import APIRouter, HTTPException, Request, Header
from pydantic import BaseModel
from typing import Optional

try:
    import stripe
    STRIPE_AVAILABLE = True
except ImportError:
    STRIPE_AVAILABLE = False

log = logging.getLogger(__name__)
router = APIRouter()

PRODUCTS = {
    "PLAN_PRO": {"credits": 600, "price_brl": 4900, "recurring": True},
    "TOPUP_100": {"credits": 100, "price_brl": 1000, "recurring": False},
}


class CheckoutRequest(BaseModel):
    product: str
    success_url: Optional[str] = None
    cancel_url: Optional[str] = None


@router.post("/stripe/checkout")
async def stripe_checkout(req: CheckoutRequest):
    """Cria Stripe Checkout Session.
    Em modo mock (sem STRIPE_SECRET_KEY) retorna URL placeholder.
    """
    if req.product not in PRODUCTS:
        raise HTTPException(status_code=400, detail="produto inválido")

    stripe_key = os.environ.get("STRIPE_SECRET_KEY")
    if not stripe_key or not STRIPE_AVAILABLE:
        # modo mock
        return {
            "session_id": "cs_test_mock_" + req.product,
            "url": "https://example.com/stripe-mock-checkout",
            "mode": "mock",
            "product": req.product,
            "credits": PRODUCTS[req.product]["credits"],
        }

    stripe.api_key = stripe_key
    try:
        session = stripe.checkout.Session.create(
            payment_method_types=["card"],
            line_items=[{
                "price_data": {
                    "currency": "brl",
                    "product_data": {"name": f"Ocean Ways {req.product}"},
                    "unit_amount": PRODUCTS[req.product]["price_brl"],
                },
                "quantity": 1,
            }],
            mode="subscription" if PRODUCTS[req.product]["recurring"] else "payment",
            success_url=req.success_url or "https://oceanways.example/success",
            cancel_url=req.cancel_url or "https://oceanways.example/cancel",
        )
        return {"session_id": session.id, "url": session.url, "mode": "live"}
    except Exception as e:
        log.error("stripe_checkout_error: %s", e)
        raise HTTPException(status_code=502, detail=f"stripe error: {e}")


@router.post("/stripe/webhook")
async def stripe_webhook(request: Request, stripe_signature: Optional[str] = Header(None)):
    """Webhook do Stripe — valida assinatura e credita usuário.
    TODO: implementar verificação real com STRIPE_WEBHOOK_SECRET + creditar Firestore.
    """
    payload = await request.body()
    webhook_secret = os.environ.get("STRIPE_WEBHOOK_SECRET")
    if not webhook_secret or not STRIPE_AVAILABLE:
        return {"received": True, "mode": "mock"}

    try:
        event = stripe.Webhook.construct_event(payload, stripe_signature, webhook_secret)
    except Exception as e:
        log.error("stripe_webhook_signature_error: %s", e)
        raise HTTPException(status_code=400, detail="invalid signature")

    if event["type"] == "checkout.session.completed":
        # TODO: creditar usuário em Firestore (idempotente por event.id)
        log.info("stripe_checkout_completed: %s", event["id"])

    return {"received": True, "event_id": event["id"]}


@router.get("/products")
async def list_products():
    """Lista produtos disponíveis."""
    return {"products": PRODUCTS, "gateway": "stripe", "mode": "live" if os.environ.get("STRIPE_SECRET_KEY") else "mock"}
